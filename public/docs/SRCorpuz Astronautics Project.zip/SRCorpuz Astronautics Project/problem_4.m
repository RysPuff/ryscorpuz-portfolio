%% Problem 4: Mission to Didymos
% Preliminary mission analysis for a transfer from Earth to Near-Earth
% Object 65803 Didymos. Covers state propagation, Lambert transfer,
% porkchop plot, and optimal trajectory visualization.

clear; close all; clc;

% Constants
AU  = 149.6e6;        % km per AU
MU  = 132712000000;   % heliocentric gravitational parameter [km^3/s^2]
DAY = 86400;          % seconds per day
deg = pi/180;         % degrees to radians

% Earth Keplerian elements at t_ref: {a, e, i, W, w, ta}
kep_Earth0 = [ 1.00000011 * AU;
               0.016710212;
               0.00005  * deg;
              -11.26064 * deg;
              102.94719 * deg;
              100.46435 * deg];

% Didymos Keplerian elements at t_ref: {a, e, i, W, w, ta}
kep_Did0 = [ 1.6442 * AU;
             0.38385;
             3.4079  * deg;
            73.196   * deg;
           319.321   * deg;
           195.0     * deg];

%% (a) Earth state at t_ref + 12 days

% propagate Earth forward 12 days from t_ref
tof_a      = 12 * DAY;
rv_Earth_a = propagate_elliptical(kep2rv(kep_Earth0, MU), tof_a, MU);

fprintf('%s\n', repmat('═', 1, 51));
fprintf('  (a) Earth at t_ref + 12 days\n');
fprintf('%s\n', repmat('═', 1, 51));
fprintf('  r = [%+.6e, %+.6e, %+.6e] km\n',   rv_Earth_a(1), rv_Earth_a(2), rv_Earth_a(3));
fprintf('  v = [%+.6f, %+.6f, %+.6f] km/s\n', rv_Earth_a(4), rv_Earth_a(5), rv_Earth_a(6));
fprintf('%s\n', repmat('═', 1, 51));

%% (b) Didymos state at t_ref + 412 days

% propagate Didymos forward 412 days from t_ref
tof_b    = 412 * DAY;
rv_Did_b = propagate_elliptical(kep2rv(kep_Did0, MU), tof_b, MU);

fprintf('%s\n', repmat('═', 1, 51));
fprintf('  (b) Didymos at t_ref + 412 days\n');
fprintf('%s\n', repmat('═', 1, 51));
fprintf('  r = [%+.6e, %+.6e, %+.6e] km\n',   rv_Did_b(1), rv_Did_b(2), rv_Did_b(3));
fprintf('  v = [%+.6f, %+.6f, %+.6f] km/s\n', rv_Did_b(4), rv_Did_b(5), rv_Did_b(6));
fprintf('%s\n', repmat('═', 1, 51));

%% Problem 4(c): Transfer from Earth to Didymos, t0=t_ref+12, tf=t_ref+412

% extract position and velocity at departure and arrival
r1_c        = rv_Earth_a(1:3);
r2_c        = rv_Did_b(1:3);
v_Earth_dep = rv_Earth_a(4:6);
v_Did_arr   = rv_Did_b(4:6);

% solve Lambert's problem for the transfer arc
tof_c            = (412 - 12) * DAY;
[v1_c, v2_c, res_c] = lambert_universal(r1_c, r2_c, tof_c, MU, 0, 1e-10, 1e-10);

% compute total delta-V at departure and arrival
dv1_c      = norm(v1_c - v_Earth_dep);
dv2_c      = norm(v2_c - v_Did_arr);
dv_total_c = dv1_c + dv2_c;

fprintf('%s\n', repmat('═', 1, 51));
fprintf('  (c) Transfer: t0=t_ref+12d, tf=t_ref+412d\n');
fprintf('%s\n', repmat('═', 1, 51));
fprintf('  Lambert residual : %.3e s\n',     res_c);
fprintf('  DV_Earth         : %+.6f km/s\n', dv1_c);
fprintf('  DV_Didymos       : %+.6f km/s\n', dv2_c);
fprintf('  DV_total         : %+.6f km/s\n', dv_total_c);
fprintf('%s\n', repmat('═', 1, 51));

% propagate transfer arc at Npts points for plotting
Npts             = 500;
rv_transfer      = zeros(6, Npts);
rv_transfer(:,1) = [r1_c; v1_c];
for k = 2:Npts
    t_k             = (k-1)/(Npts-1) * tof_c;
    rv_transfer(:,k) = propagate_elliptical(rv_transfer(:,1), t_k, MU);
end

% sample full orbits of Earth and Didymos by sweeping true anomaly
Norb          = 500;
ta_linspace   = linspace(0, 2*pi, Norb);
kep_Earth_dep = rv2kep(rv_Earth_a, MU);
kep_Did_arr   = rv2kep(rv_Did_b,   MU);

orb_Earth = zeros(3, Norb);
orb_Did   = zeros(3, Norb);
for k = 1:Norb
    kep_e          = kep_Earth_dep; kep_e(6) = ta_linspace(k);
    kep_d          = kep_Did_arr;   kep_d(6) = ta_linspace(k);
    rv_e           = kep2rv(kep_e, MU);
    rv_d           = kep2rv(kep_d, MU);
    orb_Earth(:,k) = rv_e(1:3);
    orb_Did(:,k)   = rv_d(1:3);
end

% 3D plot of transfer arc with Earth and Didymos orbits
scale = 1 / AU;
figure('Name','(c) Transfer Trajectory','Position',[100,100,900,750]);
set(gcf, 'Color', 'w');
hold on; grid on; axis equal; box on;

plot3(orb_Earth(1,:)*scale, orb_Earth(2,:)*scale, orb_Earth(3,:)*scale, ...
      'b-', 'LineWidth', 1.5, 'DisplayName', 'Earth orbit');
plot3(orb_Did(1,:)*scale, orb_Did(2,:)*scale, orb_Did(3,:)*scale, ...
      'r-', 'LineWidth', 1.5, 'DisplayName', 'Didymos orbit');
plot3(rv_transfer(1,:)*scale, rv_transfer(2,:)*scale, rv_transfer(3,:)*scale, ...
      'g-', 'LineWidth', 2, 'DisplayName', sprintf('Transfer arc  \\DeltaV = %.2f km/s', ...
      dv_total_c));
scatter3(0, 0, 0, 200, 'y', 'filled', 'DisplayName', 'Sun');
scatter3(r1_c(1)*scale, r1_c(2)*scale, r1_c(3)*scale, 80, 'b', 'filled', ...
         'DisplayName', 'Earth (departure)');
scatter3(r2_c(1)*scale, r2_c(2)*scale, r2_c(3)*scale, 80, 'r', 'filled', ...
         'DisplayName', 'Didymos (arrival)');

xlabel('x (AU)', 'Color', 'k');
ylabel('y (AU)', 'Color', 'k');
zlabel('z (AU)', 'Color', 'k');
title(sprintf('Earth \\rightarrow Didymos Transfer (\\DeltaV = %.2f km/s)', dv_total_c), 'Color', 'k');

ax           = gca;
ax.Color     = 'w';
ax.XColor    = 'k';
ax.YColor    = 'k';
ax.ZColor    = 'k';
ax.GridColor = 'k';
ax.FontSize  = 12;

legend('Location', 'best', 'TextColor', 'k', 'Color', 'w');
view(30, 25);

% save figure as PNG
figName            = '(c)_Transfer_Trajectory';
ax.Toolbar.Visible = 'off';
saveas(gcf, [figName, '.png']);

%% Problem 4(d): Porkchop plot, Earth to Didymos

% define 5-day grid from t_ref to t_ref + 1000 days
t_grid = 0 : 5 : 1000;
Ng     = length(t_grid);
DV_map = nan(Ng, Ng);

% pre-compute Earth and Didymos states at every grid epoch
rv_E0 = kep2rv(kep_Earth0, MU);
rv_D0 = kep2rv(kep_Did0,   MU);

rv_E_grid = zeros(6, Ng);
rv_D_grid = zeros(6, Ng);
for k = 1:Ng
    rv_E_grid(:,k) = propagate_elliptical(rv_E0, t_grid(k)*DAY, MU);
    rv_D_grid(:,k) = propagate_elliptical(rv_D0, t_grid(k)*DAY, MU);
end

% compute delta-V for every valid (t0, tf) pair
for i = 1:Ng
    r1_d = rv_E_grid(1:3, i);
    vE_d = rv_E_grid(4:6, i);

    for j = i+1 : Ng
        tof_d = (t_grid(j) - t_grid(i)) * DAY;

        % skip transfers shorter than 100 days
        if tof_d <= 100 * DAY
            continue
        end

        r2_d = rv_D_grid(1:3, j);
        vD_d = rv_D_grid(4:6, j);

        try
            [v1_d, v2_d, ~] = lambert_universal(r1_d, r2_d, tof_d, MU, 0, 1e-10, 1e-10);

            % skip if Lambert returned NaN or complex velocities
            if any(isnan(v1_d)) || any(isnan(v2_d))
                continue
            end

            dv_d = norm(v1_d - vE_d) + norm(v2_d - vD_d);

            if isreal(dv_d) && isfinite(dv_d) && dv_d < 150
                DV_map(i, j) = dv_d;
            end
        catch
            % Lambert did not converge — leave as NaN
        end
    end
end

% find local minimum of delta-V across the grid
DV_work        = DV_map;
DV_work(isnan(DV_work)) = inf;
[~, idx]       = min(DV_work(:));
[i_min, j_min] = ind2sub(size(DV_work), idx);
dv_min         = DV_map(i_min, j_min);

fprintf('%s\n', repmat('═', 1, 51));
fprintf('  (d) Porkchop local minimum\n');
fprintf('%s\n', repmat('═', 1, 51));
fprintf('  t0     : t_ref + %.0f days\n', t_grid(i_min));
fprintf('  tf     : t_ref + %.0f days\n', t_grid(j_min));
fprintf('  DV_min : %+.6f km/s\n',        dv_min);
fprintf('%s\n', repmat('═', 1, 51));

% save porkchop data for use in part (e)
save('porkchop_data.mat', 'DV_map', 't_grid', 'i_min', 'j_min');

% porkchop contour plot
figure('Name','(d) Porkchop Plot','Position',[100,100,1000,700]);
set(gcf, 'Color', 'w');
contourf(t_grid, t_grid, DV_map', 50, 'LineColor', 'none', 'HandleVisibility', 'off');
hold on;
contour(t_grid, t_grid, DV_map', 15, 'w', 'LineWidth', 0.5, 'HandleVisibility', 'off');

% dashed diagonal line marking tof = 100 day boundary
plot([0 900], [100 1000], 'k--', 'LineWidth', 1.5, 'DisplayName', 'Min. Allowed Flight Time');

% mark local minimum on plot
plot(t_grid(i_min), t_grid(j_min), 'r*', 'MarkerSize', 12, 'LineWidth', 1.5, ...
     'DisplayName', sprintf('Local min for Part E: \\DeltaV = %.2f km/s', dv_min));

clim([0 40]);
colormap('jet');
xlabel('Departure date, t_0 - t_{ref} [days]', 'Color', 'k');
ylabel('Arrival date, t_f - t_{ref} [days]', 'Color', 'k');
title('Porkchop Plot for Earth-to-Didymos Transfer', 'Color', 'k');

ax           = gca;
ax.Color     = 'w';
ax.XColor    = 'k';
ax.YColor    = 'k';
ax.GridColor = 'k';
ax.FontSize  = 12;
ax.XLim      = [0 1000];
ax.YLim      = [0 1000];

cb              = colorbar;
cb.Color        = 'k';
cb.Label.String = 'Total \DeltaV [km/s]';
cb.Label.Color  = 'k';

legend('Location', 'southeast', 'TextColor', 'k', 'Color', 'w');
ax.Toolbar.Visible = 'off';
saveas(gcf, '(d)_Porkchop_Plot.jpg');

%% Problem 4(e): 3D trajectory for a local minimum from porkchop plot

% load porkchop results from part (d)
load('porkchop_data.mat', 'DV_map', 't_grid', 'i_min', 'j_min');

% departure and arrival times at the local minimum
t0_e  = t_grid(i_min) * DAY;
tf_e  = t_grid(j_min) * DAY;
tof_e = tf_e - t0_e;

% propagate Earth and Didymos to optimal departure and arrival epochs
rv_E_min = propagate_elliptical(kep2rv(kep_Earth0, MU), t0_e, MU);
rv_D_min = propagate_elliptical(kep2rv(kep_Did0,   MU), tf_e, MU);
r1_e     = rv_E_min(1:3);
r2_e     = rv_D_min(1:3);
vE_e     = rv_E_min(4:6);
vD_e     = rv_D_min(4:6);

% solve Lambert for the optimal transfer
[v1_e, v2_e, ~] = lambert_universal(r1_e, r2_e, tof_e, MU, 0, 1e-10, 1e-10);
dv_e = norm(v1_e - vE_e) + norm(v2_e - vD_e);

fprintf('%s\n', repmat('═', 1, 51));
fprintf('  (e) Optimal transfer\n');
fprintf('%s\n', repmat('═', 1, 51));
fprintf('  Departure : t_ref + %.0f days\n', t_grid(i_min));
fprintf('  Arrival   : t_ref + %.0f days\n', t_grid(j_min));
fprintf('  TOF       : %.0f days\n',          tof_e / DAY);
fprintf('  DV_total  : %+.6f km/s\n',         dv_e);
fprintf('%s\n', repmat('═', 1, 51));

% propagate transfer arc at Npts points for plotting
Npts         = 500;
rv_tr_e      = zeros(6, Npts);
rv_tr_e(:,1) = [r1_e; v1_e];
for k = 2:Npts
    t_k          = (k-1)/(Npts-1) * tof_e;
    rv_tr_e(:,k) = propagate_elliptical(rv_tr_e(:,1), t_k, MU);
end

% sample full orbits by sweeping true anomaly
Norb        = 500;
ta_linspace = linspace(0, 2*pi, Norb);
kep_E_min   = rv2kep(rv_E_min, MU);
kep_D_min   = rv2kep(rv_D_min, MU);

orb_E_e = zeros(3, Norb);
orb_D_e = zeros(3, Norb);
for k = 1:Norb
    ke           = kep_E_min; ke(6) = ta_linspace(k);
    kd           = kep_D_min; kd(6) = ta_linspace(k);
    rv_e         = kep2rv(ke, MU);
    rv_d         = kep2rv(kd, MU);
    orb_E_e(:,k) = rv_e(1:3);
    orb_D_e(:,k) = rv_d(1:3);
end

% 3D plot of optimal transfer with Earth and Didymos orbits
scale = 1 / AU;
figure('Name','(e) Optimal Transfer Trajectory','Position',[100,100,900,750]);
set(gcf, 'Color', 'w');
hold on; grid on; axis equal; box on;

plot3(orb_E_e(1,:)*scale, orb_E_e(2,:)*scale, orb_E_e(3,:)*scale, ...
      'b-', 'LineWidth', 1.5, 'DisplayName', 'Earth orbit');
plot3(orb_D_e(1,:)*scale, orb_D_e(2,:)*scale, orb_D_e(3,:)*scale, ...
      'r-', 'LineWidth', 1.5, 'DisplayName', 'Didymos orbit');
plot3(rv_tr_e(1,:)*scale, rv_tr_e(2,:)*scale, rv_tr_e(3,:)*scale, ...
      'g-', 'LineWidth', 2, 'DisplayName', sprintf('Transfer arc  \\DeltaV = %.3f km/s', dv_e));
scatter3(0, 0, 0, 200, 'y', 'filled', 'DisplayName', 'Sun');
scatter3(r1_e(1)*scale, r1_e(2)*scale, r1_e(3)*scale, 80, 'b', 'filled', ...
         'DisplayName', sprintf('Earth @ t_{ref}+%dd', t_grid(i_min)));
scatter3(r2_e(1)*scale, r2_e(2)*scale, r2_e(3)*scale, 80, 'r', 'filled', ...
         'DisplayName', sprintf('Didymos @ t_{ref}+%dd', t_grid(j_min)));

xlabel('x (AU)', 'Color', 'k');
ylabel('y (AU)', 'Color', 'k');
zlabel('z (AU)', 'Color', 'k');
title(sprintf('Earth \\rightarrow Didymos Transfer (\\DeltaV = %.2f km/s)', dv_e), 'Color', 'k');

ax           = gca;
ax.Color     = 'w';
ax.XColor    = 'k';
ax.YColor    = 'k';
ax.ZColor    = 'k';
ax.GridColor = 'k';
ax.FontSize  = 12;

legend('Location', 'northeast', 'TextColor', 'k', 'Color', 'w');
view(30, 25);
ax.Toolbar.Visible = 'off';
saveas(gcf, '(e)_Optimal_Transfer_Trajectory.jpg');
