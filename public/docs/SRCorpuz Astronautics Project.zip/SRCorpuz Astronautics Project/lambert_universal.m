function [v1,v2,residual] = lambert_universal(r1,r2,tof,MU,cw,eps,tol)
    arguments (Input)
        r1  (3,1) double    % initial position vector
        r2  (3,1) double    % final position vector
        tof (1,1) double    % time of flight
        MU  (1,1) double    % gravitational parameter
        cw  (1,1) double    % whether to use clockwise path, 0 or 1
        eps (1,1) double    % tolerance for Stumpff functions near 0
        tol (1,1) double    % tolerance on root-solving
    end
    
    arguments (Output)
        v1 (3,1) double         % initial velocity vector
        v2 (3,1) double         % final velocity vector
        residual (1,1) double   % residual on converged root-solving problem
    end

% start of my code
    r1n = norm(r1);
    r2n = norm(r2);

    cos_dnu = dot(r1, r2) / (r1n * r2n);
    cos_dnu = max(-1, min(1, cos_dnu));   % clamp for safety

    cross_r = cross(r1, r2);
    dnu = acos(cos_dnu);

    if cw
        if cross_r(3) >= 0
            dnu = 2*pi - dnu;
        end
    else
        if cross_r(3) < 0
            dnu = 2*pi - dnu;
        end
    end

    A = sin(dnu) * sqrt(r1n * r2n / (1 - cos_dnu));

    function [t, dtdz] = tof_func(z)
        [C, S] = stumpff(z, eps);
        y = r1n + r2n + A * (z*S - 1) / sqrt(C);
        if y < 0
            t = -1e30;
            dtdz = 1e30;
            return
        end
        chi = sqrt(y / C);
        t   = (chi^3 * S + A * sqrt(y)) / sqrt(MU);
        h_fd   = 1e-6 * max(1, abs(z));
        [C2,S2] = stumpff(z+h_fd, eps);
        y2 = r1n + r2n + A * ((z+h_fd)*S2 - 1) / sqrt(C2);
        if y2 > 0
            chi2  = sqrt(y2/C2);
            t2    = (chi2^3*S2 + A*sqrt(y2)) / sqrt(MU);
            dtdz  = (t2 - t) / h_fd;
        else
            dtdz = 1e30;
        end
    end

    z = 0;   % initial guess (parabolic)
    maxiter = 200;
    for iter = 1:maxiter
        [t_cur, dtdz] = tof_func(z);
        f = t_cur - tof;
        if abs(dtdz) < 1e-30
            break
        end
        dz = -f / dtdz;
        dz = sign(dz) * min(abs(dz), max(1.0, abs(z)));
        z  = z + dz;
        z = max(z, -4*pi^2);
        if abs(dz) < tol && abs(f) < tol
            break
        end
    end

residual = abs(tof_func(z) - tof);

% --- Reconstruct Lagrange coefficients ---
[C, S] = stumpff(z, eps);
y   = r1n + r2n + A * (z*S - 1) / sqrt(C);
chi = sqrt(y / C);

f_lag  = 1 - y / r1n;
g_lag  = A * sqrt(y / MU);
gdot   = 1 - y / r2n;

v1 = (r2 - f_lag * r1) / g_lag;
v2 = (gdot * r2 - r1) / g_lag;

% end of my code

end


