function [C,S] = stumpff(z,eps)
    arguments (Input)
        z   (1,1) double    % function input
        eps (1,1) double    % tolerance for Stumpff functions near 0
    end

    arguments (Output)
        C (1,1) double      % Stumpff function C evaluated at z
        S (1,1) double      % Stumpff function S evaluated at z
    end
    
    % start of my code
    if abs(z) < eps
       C = 1/2 - z/24 + z^2/720 - z^3/40320;
       S = 1/6 - z/120 + z^2/5040 - z^3/362880;

    elseif z > 0
       sq = sqrt(z);
       C  = (1 - cos(sq)) / z;
       S  = (sq - sin(sq)) / (z * sq);

    else  % z < 0
       sq = sqrt(-z);
       C  = (cosh(sq) - 1) / (-z);
       S  = (sinh(sq) - sq) / ((-z) * sq);
    end

    % end of my code
    
end
