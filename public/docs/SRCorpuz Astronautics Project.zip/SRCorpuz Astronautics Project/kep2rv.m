function rv = kep2rv(kep, MU)
    arguments (Input)
        kep (6,1) double
        MU (1,1) double
    end
    arguments (Output)
        rv (6,1) double
    end

% start of my code

    a = kep(1); e = kep(2); i = kep(3); 
    W = kep(4); w = kep(5); ta = kep(6);

    p = a * (1 - e^2);
    r = p / (1 + e * cos(ta));

    % Perifocal position and velocity
    r_pqw = [r * cos(ta); r * sin(ta); 0];
    v_pqw = [-sqrt(MU/abs(p)) * sin(ta); sqrt(MU/abs(p)) * (e + cos(ta)); 0];

    % Rotation Matrix (Perifocal to Inertial)
    R = [cos(W)*cos(w)-sin(W)*sin(w)*cos(i), -cos(W)*sin(w)-sin(W)*cos(w)*cos(i),  sin(W)*sin(i);
         sin(W)*cos(w)+cos(W)*sin(w)*cos(i), -sin(W)*sin(w)+cos(W)*cos(w)*cos(i), -cos(W)*sin(i);
         sin(w)*sin(i),                       cos(w)*sin(i),                       cos(i)];

    rv = [R * r_pqw; R * v_pqw];

% end of my code
end
