function ma = ta2ma(e, ta)
    arguments (Input)
        e (1,1) double   % eccentricity
        ta (1,1) double  % true anomaly
    end

    arguments (Output)
        ma (1,1) double  % mean anomaly
    end

    % Step 1: Calculate Eccentric Anomaly (E) 
    % Using the tangent half-angle formula for better quadrant handling
    E = 2 * atan2(sqrt(1-e) * sin(ta/2), sqrt(1+e) * cos(ta/2));

    % Step 2: Kepler's Equation to find Mean Anomaly (M)
    ma = E - e * sin(E);

    % Step 3: Ensure result is in the range [0, 2*pi]
    ma = mod(ma, 2*pi);
end
