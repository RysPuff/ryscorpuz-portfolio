function rvf = propagate_elliptical(rv, tof, MU)
    arguments (Input)
        rv (6,1) double    % initial cartesian vector [r; v]
        tof (1,1) double   % time of flight
        MU (1,1) double    % gravitational parameter
    end

    arguments (Output)
        rvf (6,1) double   % final position & velocity vector [rf; vf]
    end

    % 1. Convert initial state to Keplerian elements
    % This makes use of your Problem 1(a) function
    kep = rv2kep(rv, MU);
    a = kep(1);
    e = kep(2);
    ta0 = kep(6);

    % Safety check required by the assignment
    assert(e < 1, 'Eccentricity must be less than 1 for elliptical propagation.');

    % 2. Calculate the Orbital Period (T = 2*pi*sqrt(a^3/MU))
    period = 2 * pi * sqrt(a^3 / MU);

    % 3. Propagate the true anomaly forward by the time of flight
    % This makes use of your Problem 2(c) function
    ta_f = propagate_elliptical_ta(period, e, ta0, tof);

    % 4. Update the Keplerian elements with the new true anomaly and convert back
    % This makes use of your Problem 1(b) function
    kep_final = kep;
    kep_final(6) = ta_f;
    
    rvf = kep2rv(kep_final, MU);
end