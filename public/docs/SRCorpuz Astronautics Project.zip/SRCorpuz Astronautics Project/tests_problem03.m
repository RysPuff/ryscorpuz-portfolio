%% Tests for problem 3
% MAE146 Astronautics Project - Problem 2
clear; close all;

fprintf("MAE146 Astronautics Project - Problem 3\n");

%% (a) tests for stumpff
fprintf("\n**************** stumpff ****************\n")
eps = 1e-12;
zs = [0.0 0.5 0.8 1];
CS_test = [0.5 0.166666666666667;
           0.479510805848740 0.162549260268863;
           0.467542969336544 0.160125583401161;
           0.459697694131860 0.158529015192104];
N_test = length(zs);
N_success = 0;
for j = 1:N_test
    [C,S] = stumpff(zs(j), eps);
    check = (C - CS_test(j,1) < 10*eps) && (S - CS_test(j,2) < 10*eps);
    N_success = N_success + check;
end
fprintf("Successful cases: %d / %d\n", N_success, N_test);

%% (b) tests for lambert_universal
fprintf("\n*********** lambert_universal ***********\n")
% test cases: each row contains:
%   test_caes{i,1} = r1;
%   test_caes{i,2} = r2;
%   test_caes{i,3} = tof;
%   test_caes{i,4} = cw;
%   test_caes{i,5} = v1 (output);
%   test_caes{i,6} = v2 (output);
MU = 1.0;
eps = 1e-8;
tol = 1e-8;

test_cases = {};
test_cases{1,1} = [0.3 2.4 -0.4]';
test_cases{1,2} = [0.2 -0.3 0.6]';
test_cases{1,3} = 5.4;
test_cases{1,4} = 0;
test_cases{1,5} = [-0.168832166548647 -0.128642321807441 -0.332300800305753]';
test_cases{1,6} = [0.608670081173347 0.920017394112581 0.989894709964118]';

test_cases{2,1} = [0.3 2.4 -0.4]';
test_cases{2,2} = [0.2 -0.3 0.6]';
test_cases{2,3} = 5.4;
test_cases{2,4} = 1;
test_cases{2,5} = [0.161085562054414 0.034186486555894 0.357446412995252]';
test_cases{2,6} = [-0.596284644988514 -0.987320047336352 -0.930513191363837]';

test_cases{3,1} = [1.4 0.02 0.1]';
test_cases{3,2} = [-0.5 -1.3 0.04]';
test_cases{3,3} = 3.2;
test_cases{3,4} = 0;
test_cases{3,5} = [-0.515890251165285 0.678423847270071 -0.077011808101131]';
test_cases{3,6} = [0.459636845723890 -0.725166583520697 0.075684064792198]';

test_cases{4,1} = [1.4 0.02 0.1]';
test_cases{4,2} = [-0.5 -1.3 0.04]';
test_cases{4,3} = 3.2;
test_cases{4,4} = 1;
test_cases{4,5} = [4.227313411591507e-04 -0.843089576921995 0.049404855476881]';
test_cases{4,6} = [-0.793093843032507 0.298623732750714 -0.074801541624435]';

N_test = size(test_cases,1);
N_success = 0;

for j = 1:N_test
    [v1,v2,residual] = lambert_universal(test_cases{j,1}, test_cases{j,2}, test_cases{j,3}, ...
        MU, test_cases{j,4}, 1e-8, 1e-8);

    check = check_lambert(v1,v2,test_cases{j,5},test_cases{j,6},1e-8,1e-8); %residual,tol);
    N_success = N_success + check;
end

fprintf("Successful cases: %d / %d\n", N_success, N_test);

function check = check_lambert(v1,v2,v1_check,v2_check,residual,tol)
    check = 1;
    if residual > tol
        check = 0;
    end
    if max(abs(v1-v1_check)) > tol
        check = 0;
    end
    if max(abs(v2-v2_check)) > tol
        check = 0;
    end
end


