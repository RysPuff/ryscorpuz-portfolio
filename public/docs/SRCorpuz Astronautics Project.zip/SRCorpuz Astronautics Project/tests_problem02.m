%% Tests for problem 2
% MAE146 Astronautics Project - Problem 2
clear; close all;

fprintf("MAE146 Astronautics Project - Problem 2\n");

%% (a) tests for ta2ma
fprintf("\n**************** ta2ma ****************\n")
N_test = 8;
N_success = 0;  % initialize
e_test = 0.1;
tas = linspace(0,2*pi,N_test);
mas = [0; 0.748404511629030;
    1.597224166172941; 2.599801276181623;
    3.683384030997964; 4.685961141006644;
    5.534780795550557; 6.283185307179586];
for k = 1:length(tas)
    ma = ta2ma(e_test, tas(k));
    N_success = N_success + (acos(cos(ma - mas(k))) < 1e-12);
end
fprintf("Successful cases: %d / %d\n", N_success, N_test);

%% (b) tests for ma2ta
fprintf("\n**************** ma2ta ****************\n")
N_success = 0;
for k = 1:length(tas)
    ta = ma2ta(e_test, mas(k));
    N_success = N_success + (acos(cos(ta - tas(k))) < 1e-12);
end
fprintf("Successful cases: %d / %d\n", N_success, N_test);


%% (c) tests for propagate_elliptical_ta
fprintf("\n******* propagate_elliptical_ta *******\n")
% test cases: each row contains:
%   test_caes{i,1} = period;
%   test_caes{i,2} = e;
%   test_caes{i,3} = initial true anomaly;
%   test_caes{i,4} = time of flight;
%   test_caes{i,5} = final true anomaly (output)
test_cases = {};
test_cases{1,1} = 1.4;
test_cases{1,2} = 0.3;
test_cases{1,3} = 1.1;
test_cases{1,4} = 3.8;
test_cases{1,5} = -1.780523990089403;

test_cases{2,1} = 1.2;
test_cases{2,2} = 0.8;
test_cases{2,3} = 3.1;
test_cases{2,4} = 0.6;
test_cases{2,5} = -1.800070556125062;

test_cases{3,1} = 2.1;
test_cases{3,2} = 0.0;
test_cases{3,3} = 0.4;
test_cases{3,4} = 6.1;
test_cases{3,5} = -0.198398600683774;

N_test = size(test_cases,1);
N_success = 0;

for j = 1:N_test
    taf = propagate_elliptical_ta(test_cases{j,1}, test_cases{j,2}, test_cases{j,3}, test_cases{j,4});
    N_success = N_success + (acos(cos(taf - test_cases{j,5})) < 1e-12);
end

fprintf("Successful cases: %d / %d\n", N_success, N_test);

%% (c) tests for propagate_elliptical
fprintf("\n******** propagate_elliptical *********\n")
% test cases: each row contains:
%   test_caes{i,1} = rv;
%   test_caes{i,2} = tof;
%   test_caes{i,3} = mu;
test_cases = {};
test_cases{1,1} = [0.3 2.4 0.2 0.2 -0.3 0.6]';
test_cases{1,2} = 5.2;
test_cases{1,3} = 1.0;

test_cases{2,1} = [1.2 1.9 0.95 -0.1 0.5 -0.04]';
test_cases{2,2} = -0.5;
test_cases{2,3} = 1.0;

test_cases{3,1} = [-0.2 -0.5 -2.5 -0.3 0.005 0.6]';
test_cases{3,2} = 2.5;
test_cases{3,3} = 1.0;

test_cases{4,1} = [0.4 0.4 1.5 0.9 0.3 0.1]';
test_cases{4,2} = 0.825;
test_cases{4,3} = 1.0;

test_cases{5,1} = [-1.3 -0.5 -0.1 -0.6 0.05 0.01]';
test_cases{5,2} = -1.9;
test_cases{5,3} = 1.0;

N_test = size(test_cases,1);
N_success = 0;

for j = 1:N_test
    rvf = propagate_elliptical(test_cases{j,1}, test_cases{j,2}, test_cases{j,3});
    rvf_ode = propagate_twobody_ode(test_cases{j,1}, test_cases{j,2}, test_cases{j,3});
    N_success = N_success + assert_rv(rvf, rvf_ode, 1e-11);
end

fprintf("Successful cases: %d / %d\n", N_success, N_test);


%% Helper functions for assertions
function success = assert_rv(rv, rv_check, tol)
    success = true;
    for i = 1:6
        if rv(i) - rv_check(i) > tol
            success = false;
        end
    end
end

function rvf = propagate_twobody_ode(rv, tof, MU)
    tspan = [0.0, tof];
    
    opts = odeset('RelTol',1e-13,'AbsTol',1e-14);
    [~, xs] = ode78(@(t,x) eom_twobody(t,x,MU), tspan, rv, opts);
    rvf = xs(end,:)';
end

function dx = eom_twobody(t,x,MU)
    dx = [x(4:6); -MU/norm(x(1:3))^3 * x(1:3)];
end
