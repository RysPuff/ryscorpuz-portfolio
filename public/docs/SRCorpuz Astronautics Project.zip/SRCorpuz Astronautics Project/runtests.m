%% Run all tests for MAE146 project
% MAE146 Astronautics Project
clear; close all; clc;

fprintf('-------------------------------------------------------------\n');
tests_problem01;
fprintf('-------------------------------------------------------------\n');
tests_problem02;
fprintf('-------------------------------------------------------------\n');
tests_problem03;
fprintf('-------------------------------------------------------------\n');