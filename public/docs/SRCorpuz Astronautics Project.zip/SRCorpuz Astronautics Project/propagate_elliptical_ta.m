function ta = propagate_elliptical_ta(period, e, ta0, tof)
    arguments (Input)
        period (1,1) double   % period
        e      (1,1) double   % eccentricity
        ta0    (1,1) double   % initial true anomaly
        tof    (1,1) double   % time of flight
    end
    arguments (Output)
        ta     (1,1) double   % true anomaly after tof
    end

    assert(e < 1)

    % 1. Calculate Mean Motion (n)
    n = (2 * pi) / period;

    % 2. Convert initial true anomaly to initial mean anomaly
    % Use your function from Problem 2(a)
    ma0 = ta2ma(e, ta0);

    % 3. Propagate Mean Anomaly forward in time
    ma_f = ma0 + n * tof;

    % 4. Convert future mean anomaly back to true anomaly
    % Use your function from Problem 2(b)
    ta = ma2ta(e, ma_f);
end