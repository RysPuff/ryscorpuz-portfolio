function ta = ma2ta(e, ma)
    arguments (Input)
        e (1,1) double   % eccentricity
        ma (1,1) double  % mean anomaly
    end

    arguments (Output)
        ta (1,1) double  % true anomaly
    end

    % Step 1: Newton-Raphson Iteration to find Eccentric Anomaly (E)
    E = ma;             % Initial guess: E_0 = M
    tol = 1e-12;        % Convergence tolerance
    max_iter = 100;     % Safety break
    
    for k = 1:max_iter
        % f(E) = E - e*sin(E) - M
        % f'(E) = 1 - e*cos(E)
        f_E = E - e * sin(E) - ma;
        df_E = 1 - e * cos(E);
        
        E_next = E - (f_E / df_E);
        
        if abs(E_next - E) < tol
            E = E_next;
            break;
        end
        E = E_next;
    end

    % Step 2: Convert Eccentric Anomaly (E) to True Anomaly (ta)
    ta = 2 * atan2(sqrt(1+e) * sin(E/2), sqrt(1-e) * cos(E/2));

    % Step 3: Ensure result is in the range [0, 2*pi]
    ta = mod(ta, 2*pi);
end