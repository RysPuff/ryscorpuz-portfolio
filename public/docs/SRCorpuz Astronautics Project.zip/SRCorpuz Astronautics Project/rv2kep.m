function kep = rv2kep(rv, MU)
    arguments (Input)
        rv (6,1) double    % cartesian vector [r; v]
        MU (1,1) double    % gravitational parameter
    end

    arguments (Output)
        kep (6,1) double   % Keplerian elements vector [a; e; i; W; w; ta]
    end

% Extracting r and v vectors 
    r_vec = rv(1:3);
    v_vec = rv(4:6);
    r = norm(r_vec);
    v = norm(v_vec);

    % 1. Specific Angular Momentum
    h_vec = cross(r_vec, v_vec);
    h = norm(h_vec);

    % 2. Inclination (i)
    i = acos(h_vec(3) / h);

    % 3. Node Vector and RAAN (W)
    n_vec = cross([0;0;1], h_vec);
    n = norm(n_vec);
    if n ~= 0
       W = acos(n_vec(1) / n);
        if n_vec(2) < 0, W = 2*pi - W; end
        else
        W = 0; % Equatorial orbit case
    end

    % 4. Eccentricity (e)
    e_vec = ((v^2 - MU/r)*r_vec - dot(r_vec, v_vec)*v_vec) / MU;
    e = norm(e_vec);

    % 5. Semi-major Axis (a)
    energy = (v^2 / 2) - (MU / r);
    a = -MU / (2 * energy);

    % 6. Argument of Periapsis (w)
    if n ~= 0 && e > 1e-10
        w = acos(dot(n_vec, e_vec) / (n * e));
        if e_vec(3) < 0, w = 2*pi - w; end
    else
        w = 0; 
    end

    % 7. True Anomaly (ta)
    if e > 1e-10
        ta = acos(dot(e_vec, r_vec) / (e * r));
        if dot(r_vec, v_vec) < 0, ta = 2*pi - ta; end
    else
        % If circular, use angle from node vector
        ta = acos(dot(n_vec, r_vec) / (n * r));
    end

    kep = [a; e; i; W; w; ta];
    end
