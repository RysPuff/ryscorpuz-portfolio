%% Tests for problem 1
% MAE146 Astronautics Project - Problem 1
clear; close all;

fprintf("MAE146 Astronautics Project - Problem 1\n");

% test cases: each row contains
%   test_cases{i,1} = mu;       % gravitational parameter
%   test_cases{i,2} = rv;       % Cartesian state [r_vec; v_vec] 
%   test_cases{i,3} = kep;      % Keplerian elements [a,e,i,W,w,ta]
test_cases = {};
test_cases{1,1} = 1.0;
test_cases{1,2} = [0.3 2.4 0.2 0.2 -1.3 0.6]';
test_cases{1,3} = [-0.789942854198892; ...
                    2.375178938177648; ...
                    2.042442119967385; ...
                    1.488628804433197; ...
                    1.446705972850138; ...
                    4.929120270996203];

test_cases{2,1} = 1.0;
test_cases{2,2} = [-2.3; -0.3; 0.2; -0.3; 0.3; 0.6];
test_cases{2,3} = [3.134073542744339; ...
                   0.481189401465423; ...
                   2.097410388548883; ...
                   3.321446153382271; ...
                   4.883675331652480; ...
                   1.499044960238861];

test_cases{3,1} = 1.0;
test_cases{3,2} = [2; 2; 2; -0.4; 0.2; 0.4];
test_cases{3,3} = [4.600868467881017; ...
                   0.309552709843020; ...
                   0.941781524368221; ...
                   0.244978663126865; ...
                   6.213813627267990; ...
                   0.864574393201273];

test_cases{4,1} = 1.0;
test_cases{4,2} = [-3.787421622506193; ...
                    3.426328575507719; ...
                    0.977604186791265; ...
                    -0.297565055337378; ...
                    -0.320888489053930;...
                    -0.028165719277897];
test_cases{4,3} = [5.2; ...
                   0.0; ...
                   0.2; ...
                   0.5; ...
                   0.0; ...
                   1.9];

N_cases = size(test_cases,1);
N_test = 0;
N_success = 0;


%% (a) tests for rv2kep
fprintf("\n**************** rv2kep ****************\n")
tol = 1e-8;
for j = 1:N_cases
    fprintf('(%d) ... ', j);
    kep = rv2kep(test_cases{j,2}, test_cases{j,1});
    check = assert_kep(kep, test_cases{j,3}, tol);
    fprintf('suceess: %d (max diff: %1.3e)\n', check, max(abs(kep - test_cases{j,3})));
    N_success = N_success + check;
    N_test = N_test + 1;
end


%% (b) tests for kep2rv
fprintf("\n**************** kep2rv ****************\n")
tol = 1e-8;
for j = 1:N_cases
    fprintf('(%d) ... ', j);
    rv = kep2rv(test_cases{j,3}, test_cases{j,1});
    check = max(abs(rv - test_cases{j,2})) < tol;
    if check
        fprintf('suceess: %d (max diff: %1.3e)\n', true, max(abs(rv - test_cases{j,2})));
    else
        fprintf('suceess: %d (max diff: %1.3e)\n', false, max(abs(rv - test_cases{j,2})));
    end
    N_success = N_success + check;
    N_test = N_test + 1;
end

fprintf("\nSuccessful cases: %d / %d\n", N_success, N_test);


%% Helper functions for assertions
function success = assert_kep(kep, kep_check, tol)
    success = true;
    if kep(1) - kep_check(1) > tol
        success = false;
    end
    if kep(2) - kep_check(2) > tol
        success = false;
    end
    if acos(cos(kep(4) - kep_check(4))) > tol
        success = false;
    end
    if acos(cos(kep(4) - kep_check(4))) > tol
        success = false;
    end
    if acos(cos(kep(5) - kep_check(5))) > tol
        success = false;
    end
    if acos(cos(kep(6) - kep_check(6))) > tol
        success = false;
    end
end
